import { createFileRoute } from "@tanstack/react-router";
import { NexusApp } from "@/components/nexus/App";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "NEXUS TERMINAL — Mobile Linux & Dev Environment" },
      { name: "description", content: "Run scripts, clone repos and stream live terminal logs from a sleek mobile dev console." },
      { property: "og:title", content: "NEXUS TERMINAL — Mobile Linux & Dev Environment" },
      { property: "og:description", content: "Run scripts, clone repos and stream live terminal logs from a sleek mobile dev console." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: NexusApp,
});
