import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { ChevronLeft, type LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

export type ScreenId =
  | "home" | "terminal" | "tabs" | "history" | "explorer" | "preview" | "editor" | "projects"
  | "packages" | "pkg" | "linux" | "network" | "ssh" | "ai" | "monitor" | "plugins" | "downloads"
  | "browser" | "database" | "notifications" | "security" | "theme" | "settings" | "about" | "apps";

type Nav = { go: (s: ScreenId, param?: string) => void; back: () => void; param?: string; reduce: boolean; setReduce: (v: boolean) => void };
export const NavCtx = createContext<Nav>(null as unknown as Nav);
export const useNav = () => useContext(NavCtx);

export function Card({ className, children, delay = 0, onClick }: { className?: string; children: ReactNode; delay?: number; onClick?: () => void }) {
  const C = onClick ? "button" : "div";
  return (
    <C onClick={onClick} style={{ animationDelay: `${delay}ms` }}
      className={cn("rise block w-full rounded-3xl border border-border bg-card/80 p-4 text-left", onClick && "press", className)}>
      {children}
    </C>
  );
}

export type Status = "Active" | "Running" | "Ready" | "Failed" | "Installed" | "Online" | "Offline" | "Mock";
export function Pill({ status, label }: { status: Status; label?: string | undefined }) {
  const map: Record<Status, string> = {
    Running: "bg-primary/15 text-primary border-primary/30",
    Active: "bg-success/15 text-success border-success/30",
    Online: "bg-success/15 text-success border-success/30",
    Installed: "bg-success/15 text-success border-success/30",
    Ready: "bg-secondary text-muted-foreground border-border",
    Offline: "bg-secondary text-muted-foreground border-border",
    Failed: "bg-destructive/15 text-destructive border-destructive/30",
    Mock: "bg-accent text-accent-foreground border-primary/20",
  };
  return (
    <span className={cn("inline-flex shrink-0 items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[11px] font-medium", map[status])}>
      {(status === "Running" || status === "Online") && <span className={cn("h-1.5 w-1.5 animate-pulse rounded-full", status === "Running" ? "bg-primary" : "bg-success")} />}
      {label ?? status}
    </span>
  );
}

/** iOS-style round glass icon button */
export function IconBtn({ icon: Icon, onClick, label, active, size = "md" }: { icon: LucideIcon; onClick?: () => void; label: string; active?: boolean; size?: "sm" | "md" | "lg" }) {
  const s = { sm: "h-9 w-9", md: "h-11 w-11", lg: "h-14 w-14" }[size];
  return (
    <button aria-label={label} onClick={onClick}
      className={cn("ios-btn flex shrink-0 items-center justify-center rounded-full", s, active && "bg-ember text-primary-foreground shadow-glow")}>
      <Icon className={size === "lg" ? "h-6 w-6" : "h-[18px] w-[18px]"} strokeWidth={2.2} />
    </button>
  );
}

/** iOS home-screen style app tile */
export function AppTile({ icon: Icon, label, onClick, accent, delay = 0 }: { icon: LucideIcon; label: string; onClick?: () => void; accent?: boolean | undefined; delay?: number }) {
  return (
    <button onClick={onClick} style={{ animationDelay: `${delay}ms` }} className="rise flex flex-col items-center gap-1.5">
      <span className={cn("ios-tile flex h-14 w-14 items-center justify-center", accent ? "ember-flow text-primary-foreground shadow-glow" : "text-primary")}>
        <Icon className="h-6 w-6" strokeWidth={2} />
      </span>
      <span className="max-w-16 truncate text-[11px] text-muted-foreground">{label}</span>
    </button>
  );
}

export function Btn({ children, onClick, variant = "primary", className, type }: { children: ReactNode; onClick?: () => void; variant?: "primary" | "glass" | "danger"; className?: string; type?: "submit" }) {
  const v = {
    primary: "bg-ember text-primary-foreground shadow-glow press",
    glass: "ios-btn text-foreground",
    danger: "ios-btn text-destructive",
  }[variant];
  return <button type={type} onClick={onClick} className={cn("flex h-12 items-center justify-center gap-2 rounded-2xl px-5 text-sm font-semibold", v, className)}>{children}</button>;
}

export function Toggle({ on, onChange }: { on: boolean; onChange: () => void }) {
  return (
    <button role="switch" aria-checked={on} onClick={onChange} className={cn("relative h-[31px] w-[51px] shrink-0 rounded-full transition-colors duration-300", on ? "bg-ember" : "bg-secondary")}>
      <span className={cn("absolute top-[2px] h-[27px] w-[27px] rounded-full bg-foreground shadow-md transition-all duration-300 [transition-timing-function:var(--ease-spring)]", on ? "left-[22px]" : "left-[2px]")} />
    </button>
  );
}

export function Row({ icon: Icon, title, sub, right, onClick }: { icon?: LucideIcon; title: string; sub?: string | undefined; right?: ReactNode; onClick?: () => void }) {
  const C = onClick ? "button" : "div";
  return (
    <C onClick={onClick} className={cn("flex w-full items-center gap-3 px-4 py-3 text-left", onClick && "press")}>
      {Icon && <span className="ios-tile flex h-9 w-9 items-center justify-center text-primary"><Icon className="h-[18px] w-[18px]" /></span>}
      <div className="min-w-0 flex-1"><p className="truncate text-sm font-medium">{title}</p>{sub && <p className="truncate font-mono text-[11px] text-muted-foreground">{sub}</p>}</div>
      {right}
    </C>
  );
}

export function Group({ children, title, delay = 0 }: { children: ReactNode; title?: string; delay?: number }) {
  return (
    <section className="rise" style={{ animationDelay: `${delay}ms` }}>
      {title && <h3 className="mb-2 px-1 text-xs font-semibold uppercase tracking-widest text-muted-foreground">{title}</h3>}
      <div className="divide-y divide-border overflow-hidden rounded-3xl border border-border bg-card/80">{children}</div>
    </section>
  );
}

export function Progress({ value, className }: { value: number; className?: string }) {
  return (
    <div className={cn("h-1.5 overflow-hidden rounded-full bg-secondary", className)}>
      <div className="relative h-full rounded-full bg-ember transition-all duration-500" style={{ width: `${value}%` }}>
        <div className="shimmer absolute inset-0" />
      </div>
    </div>
  );
}

export function Ring({ value, label, size = 72 }: { value: number; label: string; size?: number }) {
  const r = size / 2 - 6, c = 2 * Math.PI * r;
  return (
    <div className="flex flex-col items-center gap-1">
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90">
          <circle cx={size / 2} cy={size / 2} r={r} stroke="var(--secondary)" strokeWidth="6" fill="none" />
          <circle cx={size / 2} cy={size / 2} r={r} stroke="var(--primary)" strokeWidth="6" fill="none" strokeLinecap="round"
            strokeDasharray={c} strokeDashoffset={c * (1 - value / 100)} style={{ transition: "stroke-dashoffset 1s var(--ease-out)" }} />
        </svg>
        <span className="absolute inset-0 flex items-center justify-center font-mono text-sm font-semibold">{Math.round(value)}%</span>
      </div>
      <span className="text-[11px] text-muted-foreground">{label}</span>
    </div>
  );
}

export function Spark({ pts, h = 64 }: { pts: number[]; h?: number }) {
  const w = 300, max = Math.max(...pts) * 1.1;
  const d = pts.map((p, i) => `${(i / (pts.length - 1)) * w},${h - (p / max) * h}`).join(" L");
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full" style={{ height: h }} preserveAspectRatio="none">
      <defs><linearGradient id="sg" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="var(--primary)" stopOpacity="0.4" /><stop offset="1" stopColor="var(--primary)" stopOpacity="0" /></linearGradient></defs>
      <path d={`M${d} L${w},${h} L0,${h} Z`} fill="url(#sg)" />
      <path d={`M${d}`} fill="none" stroke="var(--primary)" strokeWidth="2.5" strokeLinecap="round" />
    </svg>
  );
}

/** Live-ish mock metric that wanders */
export function useWander(start: number, min = 5, max = 95, ms = 1500) {
  const [v, setV] = useState(start);
  useEffect(() => {
    const t = setInterval(() => setV((x) => Math.min(max, Math.max(min, x + (Math.random() - 0.5) * 12))), ms);
    return () => clearInterval(t);
  }, [min, max, ms]);
  return v;
}

export function SubHeader({ title, right }: { title: string; right?: ReactNode }) {
  const { back } = useNav();
  return (
    <div className="mb-4 flex items-center gap-3">
      <IconBtn icon={ChevronLeft} label="Back" onClick={back} />
      <h2 className="flex-1 text-xl font-semibold">{title}</h2>
      {right}
    </div>
  );
}

export function Chips({ items, value, onChange }: { items: string[]; value: string; onChange: (v: string) => void }) {
  return (
    <div className="no-scrollbar -mx-5 flex gap-2 overflow-x-auto px-5 pb-1">
      {items.map((f) => (
        <button key={f} onClick={() => onChange(f)}
          className={cn("press shrink-0 rounded-full border px-4 py-2 text-xs transition-colors", value === f ? "border-primary bg-primary/15 text-primary" : "ios-btn text-muted-foreground")}>{f}</button>
      ))}
    </div>
  );
}

export function MockNote({ text = "Prototype UI · sample data · no real Linux operations run" }: { text?: string }) {
  return <p className="rise mt-4 text-center font-mono text-[10px] text-muted-foreground/70">⚠ {text}</p>;
}

export const inputCls = "h-12 w-full rounded-2xl border border-border bg-secondary/60 px-4 font-mono text-sm outline-none transition focus:border-primary focus:shadow-glow";
