import { useEffect, useState } from "react";
import { Package, Download, RefreshCw, Archive, RotateCcw, Box, Server, Globe, Wifi, Radio, Search, KeyRound, Plus, Terminal, Cpu, MemoryStick, HardDrive, Battery, Activity, X, Clock, Users, Variable, GitBranch, Lock } from "lucide-react";
import { cn } from "@/lib/utils";
import { Card, Pill, IconBtn, Btn, Group, Row, Progress, Ring, Spark, useWander, useNav, SubHeader, Chips, MockNote, inputCls, Toggle } from "./ui";

type P = { n: string; v: string; d: string; size: string; installed: boolean; cat: string };
const pkgs: P[] = [
  { n: "python", v: "3.12.4", d: "Python 3 programming language", size: "28 MB", installed: true, cat: "Languages" },
  { n: "nodejs", v: "22.3.0", d: "JavaScript runtime built on V8", size: "34 MB", installed: false, cat: "Languages" },
  { n: "git", v: "2.45.2", d: "Distributed version control", size: "12 MB", installed: true, cat: "Dev tools" },
  { n: "neovim", v: "0.10.0", d: "Hyperextensible Vim-based editor", size: "9 MB", installed: true, cat: "Editors" },
  { n: "openssh", v: "9.7p1", d: "SSH client and server", size: "4 MB", installed: false, cat: "Network" },
  { n: "postgresql", v: "16.3", d: "Object-relational SQL database", size: "41 MB", installed: false, cat: "Databases" },
  { n: "rust", v: "1.79.0", d: "Systems programming language", size: "210 MB", installed: false, cat: "Languages" },
  { n: "htop", v: "3.3.0", d: "Interactive process viewer", size: "0.4 MB", installed: false, cat: "Dev tools" },
];

export function PackagesScreen() {
  const { go } = useNav();
  const [list, setList] = useState(pkgs);
  const [prog, setProg] = useState<Record<string, number>>({});
  const [f, setF] = useState("All");
  const [q, setQ] = useState("");
  const install = (n: string) => {
    let p = 0;
    const t = setInterval(() => {
      p += 10; setProg((x) => ({ ...x, [n]: p }));
      if (p >= 100) { clearInterval(t); setList((l) => l.map((x) => (x.n === n ? { ...x, installed: true } : x))); setProg((x) => { const y = { ...x }; delete y[n]; return y; }); }
    }, 200);
  };
  const shown = list.filter((p) => p.n.includes(q) && (f === "All" || (f === "Installed" ? p.installed : f === "Recommended" ? !p.installed : p.cat === f)));
  return (
    <div className="space-y-4">
      <div className="relative"><Search className="absolute left-4 top-4 h-4 w-4 text-muted-foreground" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search 2,400+ packages…" className={cn(inputCls, "pl-10")} /></div>
      <div className="grid grid-cols-4 gap-2">
        {[[RefreshCw, "Update"], [Download, "Upgrade"], [Archive, "Backup"], [RotateCcw, "Restore"]].map(([I, l]) => {
          const Icon = I as typeof Package;
          return <button key={l as string} className="ios-btn flex flex-col items-center gap-1 rounded-2xl py-3 text-[11px]"><Icon className="h-5 w-5 text-primary" />{l as string}</button>;
        })}
      </div>
      <Chips items={["All", "Installed", "Recommended", "Languages", "Dev tools", "Network", "Databases"]} value={f} onChange={setF} />
      <div className="space-y-2">
        {shown.map((p, i) => (
          <Card key={p.n} delay={i * 40} className="p-3">
            <div className="flex items-center gap-3">
              <button onClick={() => go("pkg", p.n)} className="ios-tile flex h-11 w-11 items-center justify-center text-primary"><Package className="h-5 w-5" /></button>
              <button onClick={() => go("pkg", p.n)} className="min-w-0 flex-1 text-left">
                <p className="font-mono text-sm font-semibold">{p.n} <span className="text-[11px] font-normal text-muted-foreground">{p.v}</span></p>
                <p className="truncate text-xs text-muted-foreground">{p.d}</p>
              </button>
              {p.installed ? <Pill status="Installed" /> : prog[p.n] === undefined ? (
                <button onClick={() => install(p.n)} className="press rounded-full bg-ember px-4 py-2 text-xs font-semibold text-primary-foreground shadow-glow">GET</button>
              ) : <span className="font-mono text-xs text-primary">{prog[p.n]}%</span>}
            </div>
            {prog[p.n] !== undefined && <Progress value={prog[p.n]!} className="mt-3" />}
          </Card>
        ))}
      </div>
      <Group title="Repositories">
        <Row icon={Server} title="termux-main" sub="packages.termux.dev/apt/termux-main" right={<Pill status="Online" />} />
        <Row icon={Server} title="x11-repo" sub="packages.termux.dev/apt/termux-x11" right={<Pill status="Offline" label="Disabled" />} />
      </Group>
      <Group title="Install history">
        {["git 2.45.2 · Nov 22", "python 3.12.4 · Nov 20", "neovim 0.10.0 · Nov 18"].map((h) => <Row key={h} icon={Clock} title={h} />)}
      </Group>
      <MockNote text="Install simulation only · real installs use pkg/apt" />
    </div>
  );
}

export function PkgDetailScreen() {
  const { param } = useNav();
  const p = pkgs.find((x) => x.n === param) ?? pkgs[0]!;
  return (
    <div className="space-y-4">
      <SubHeader title="Package" />
      <Card className="relative overflow-hidden text-center">
        <div className="orb absolute -top-16 left-1/2 h-40 w-40 -translate-x-1/2 rounded-full opacity-40" />
        <div className="ios-tile relative mx-auto flex h-20 w-20 items-center justify-center text-primary"><Package className="h-10 w-10" /></div>
        <h2 className="mt-3 font-mono text-2xl font-semibold">{p.n}</h2>
        <p className="text-sm text-muted-foreground">{p.d}</p>
        <div className="mt-4 grid grid-cols-3 divide-x divide-border rounded-2xl bg-background/60 py-3 text-xs">
          <div><p className="font-mono font-semibold">{p.v}</p><p className="text-muted-foreground">Version</p></div>
          <div><p className="font-mono font-semibold">{p.size}</p><p className="text-muted-foreground">Size</p></div>
          <div><p className="font-mono font-semibold">termux-main</p><p className="text-muted-foreground">Repo</p></div>
        </div>
      </Card>
      {p.installed ? <div className="grid grid-cols-2 gap-2"><Btn variant="glass"><RefreshCw className="h-4 w-4" />Update</Btn><Btn variant="danger">Uninstall</Btn></div> : <Btn className="w-full"><Download className="h-4 w-4" />Install</Btn>}
      <Group title="Dependencies">{["libc++", "openssl", "zlib", "libffi"].map((d) => <Row key={d} icon={Box} title={d} sub="auto-installed" />)}</Group>
      <Card className="font-mono text-xs text-muted-foreground"><p className="text-primary">$ pkg install {p.n}</p><p>Reading package lists… Done</p><p>The following NEW packages will be installed: {p.n}</p></Card>
    </div>
  );
}

export function LinuxScreen() {
  const [shell, setShell] = useState("zsh");
  return (
    <div className="space-y-4">
      <SubHeader title="Linux Environment" />
      <Chips items={["bash", "zsh", "sh", "fish"]} value={shell} onChange={setShell} />
      <Group title="Distributions (PRoot)">
        <Row icon={Box} title="Debian 12 bookworm" sub="rootless · 1.2 GB" right={<Pill status="Running" />} />
        <Row icon={Box} title="Ubuntu 24.04 noble" sub="rootless · 1.6 GB" right={<Pill status="Ready" label="Installed" />} />
        <Row icon={Box} title="Arch Linux ARM" sub="not installed" right={<button className="press rounded-full bg-ember px-3 py-1.5 text-xs font-semibold text-primary-foreground">GET</button>} />
      </Group>
      <Group title="User">
        <Row icon={Users} title="u0_a312" sub="uid=10312 gid=10312 · home: /data/…/home" />
        <Row icon={Variable} title="Environment variables" sub="PATH, HOME, PREFIX, LANG + 6 more" />
      </Group>
      <Group title="Background & scheduled">
        <Row icon={Activity} title="node server.js" sub="pid 412 · 2h 14m" right={<Pill status="Running" />} />
        <Row icon={Clock} title="backup.sh" sub="cron · every day 02:00" right={<Pill status="Active" label="Scheduled" />} />
        <Row icon={GitBranch} title="git auto-sync" sub="every 30 min" right={<Pill status="Ready" label="Paused" />} />
      </Group>
      <Card><div className="mb-2 flex justify-between text-xs"><span>Linux rootfs storage</span><span className="font-mono text-muted-foreground">2.8 / 8 GB</span></div><Progress value={35} /></Card>
      <MockNote />
    </div>
  );
}

const tools = ["Ping", "DNS", "Curl", "Wget", "Ports", "HTTP server"];
export function NetworkScreen() {
  const { go } = useNav();
  const [t, setT] = useState("Ping");
  const [host, setHost] = useState("github.com");
  const [out, setOut] = useState<string[]>([]);
  const [srv, setSrv] = useState(false);
  const run = () => {
    const base = t === "Ping" ? ["PING github.com (140.82.121.4): 56 bytes", "64 bytes: icmp_seq=0 ttl=55 time=38.2 ms", "64 bytes: icmp_seq=1 ttl=55 time=36.9 ms", "--- 2 packets, 0% loss ---"]
      : t === "DNS" ? [`${host}  A  140.82.121.4`, `${host}  AAAA  —`, "resolver: 1.1.1.1"]
      : t === "Ports" ? [`${host}:22  open`, `${host}:80  open`, `${host}:443 open`, `${host}:5432 closed`]
      : [`HTTP/2 200`, "content-type: text/html", "content-length: 241812"];
    setOut([]); base.forEach((l, i) => setTimeout(() => setOut((o) => [...o, l]), 250 * (i + 1)));
  };
  return (
    <div className="space-y-4">
      <Card className="relative overflow-hidden">
        <div className="flex items-center gap-3"><span className="ember-flow flex h-12 w-12 items-center justify-center rounded-2xl"><Wifi className="h-6 w-6 text-primary-foreground" /></span>
          <div className="flex-1"><p className="font-semibold">Wi-Fi · HomeNet_5G</p><p className="font-mono text-[11px] text-muted-foreground">192.168.1.42 · public 203.0.113.18</p></div><Pill status="Online" /></div>
        <div className="mt-3 grid grid-cols-2 gap-2 font-mono text-xs"><div className="rounded-2xl bg-background/60 p-3">↓ 48.2 Mb/s</div><div className="rounded-2xl bg-background/60 p-3">↑ 12.6 Mb/s</div></div>
      </Card>
      <Chips items={tools} value={t} onChange={setT} />
      {t === "HTTP server" ? (
        <Card className="flex items-center gap-3"><Server className="h-5 w-5 text-primary" /><div className="flex-1"><p className="text-sm font-medium">python -m http.server 8000</p><p className="font-mono text-[11px] text-muted-foreground">http://localhost:8000</p></div><Toggle on={srv} onChange={() => setSrv(!srv)} /></Card>
      ) : (
        <div className="flex gap-2"><input value={host} onChange={(e) => setHost(e.target.value)} className={inputCls} /><Btn onClick={run}>Run</Btn></div>
      )}
      {out.length > 0 && <Card className="font-mono text-xs">{out.map((l, i) => <p key={i} className="rise text-muted-foreground">{l}</p>)}</Card>}
      <Group title="Connections">
        <Row icon={KeyRound} title="SSH / SFTP" sub="3 saved hosts" onClick={() => go("ssh")} />
        <Row icon={GitBranch} title="Git remotes" sub="origin → github.com/sadesha/*" />
        <Row icon={Radio} title="Tailscale" sub="where supported" right={<Pill status="Offline" />} />
        <Row icon={Lock} title="VPN" sub="where supported" right={<Pill status="Offline" />} />
        <Row icon={Globe} title="Port forwarding" sub="8080 → 80 · localhost" right={<Pill status="Active" />} />
      </Group>
      <MockNote />
    </div>
  );
}

export function SshScreen() {
  const [hosts, setHosts] = useState([
    { n: "Production VPS", h: "ubuntu@203.0.113.7", s: "Online" as const },
    { n: "Raspberry Pi", h: "pi@192.168.1.20", s: "Online" as const },
    { n: "Staging", h: "deploy@staging.example.com", s: "Offline" as const },
  ]);
  const [conn, setConn] = useState<string | null>(null);
  return (
    <div className="space-y-4">
      <SubHeader title="SSH Manager" right={<IconBtn icon={Plus} label="Add host" active onClick={() => setHosts([...hosts, { n: "New host", h: "user@host", s: "Offline" }])} />} />
      {hosts.map((h, i) => (
        <Card key={h.n + i} delay={i * 60}>
          <div className="flex items-center gap-3">
            <span className="ios-tile flex h-11 w-11 items-center justify-center text-primary"><Terminal className="h-5 w-5" /></span>
            <div className="min-w-0 flex-1"><p className="font-semibold">{h.n}</p><p className="truncate font-mono text-[11px] text-muted-foreground">{h.h}</p></div>
            <Pill status={conn === h.h ? "Running" : h.s} label={conn === h.h ? "Connected" : undefined} />
          </div>
          <div className="mt-3 grid grid-cols-2 gap-2"><Btn onClick={() => setConn(conn === h.h ? null : h.h)} className="h-10">{conn === h.h ? "Disconnect" : "SSH"}</Btn><Btn variant="glass" className="h-10">SFTP</Btn></div>
        </Card>
      ))}
      <Group title="SSH keys">
        <Row icon={KeyRound} title="id_ed25519" sub="SHA256:k3Qx…9fP2 · private key hidden" right={<Lock className="h-4 w-4 text-muted-foreground" />} />
        <Row icon={KeyRound} title="github_deploy" sub="SHA256:Za81…mQ0c · private key hidden" right={<Lock className="h-4 w-4 text-muted-foreground" />} />
      </Group>
      <Btn variant="glass" className="w-full"><Plus className="h-4 w-4" />Generate new key</Btn>
    </div>
  );
}

export function MonitorScreen() {
  const cpu = useWander(32), ram = useWander(56, 40, 85), net = useWander(40, 5, 95, 900);
  const [hist, setHist] = useState<number[]>(Array(20).fill(30));
  useEffect(() => { setHist((h) => [...h.slice(1), cpu]); }, [cpu]);
  const [procs, setProcs] = useState([
    ["node", 412, 12.4, 180], ["zsh", 301, 0.3, 8], ["sshd", 118, 0.1, 6], ["python3", 520, 6.8, 94], ["postgres", 610, 2.1, 72],
  ] as [string, number, number, number][]);
  return (
    <div className="space-y-4">
      <SubHeader title="System Monitor" />
      <Card><div className="flex justify-around"><Ring value={cpu} label="CPU · 8 cores" size={84} /><Ring value={ram} label="RAM · 7.6 GB" size={84} /><Ring value={71} label="Storage" size={84} /></div></Card>
      <Card><div className="flex justify-between text-sm"><span className="font-semibold">CPU load</span><span className="font-mono text-primary">{cpu.toFixed(0)}%</span></div><Spark pts={hist} h={70} /></Card>
      <div className="grid grid-cols-2 gap-3">
        <Card className="p-3"><Activity className="h-5 w-5 text-primary" /><p className="mt-2 font-mono text-lg font-semibold">{(net / 2).toFixed(1)} Mb/s</p><p className="text-[11px] text-muted-foreground">Network</p></Card>
        <Card className="p-3"><Battery className="h-5 w-5 text-success" /><p className="mt-2 font-mono text-lg font-semibold">78%</p><p className="text-[11px] text-muted-foreground">Battery · 31°C</p></Card>
      </div>
      <Group title="Processes">
        {procs.map(([n, pid, c, m]) => (
          <Row key={pid} icon={Cpu} title={n} sub={`pid ${pid} · ${c}% cpu · ${m} MB`} right={<IconBtn icon={X} size="sm" label="Kill" onClick={() => setProcs(procs.filter((p) => p[1] !== pid))} />} />
        ))}
      </Group>
      <Group title="System"><Row icon={HardDrive} title="Device" sub="Pixel 8 · Android 14 · aarch64" /><Row icon={MemoryStick} title="Kernel" sub="6.1.57-android14" /></Group>
      <MockNote text="Simulated metrics · real values come from native Android APIs" />
    </div>
  );
}
