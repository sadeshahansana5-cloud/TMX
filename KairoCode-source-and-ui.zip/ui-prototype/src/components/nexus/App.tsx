import { useState } from "react";
import { Home, TerminalSquare, FolderOpen, Package, Grid2x2, Network, Cpu, KeyRound, Code2, Box } from "lucide-react";
import { cn } from "@/lib/utils";
import { NavCtx, type ScreenId, AppTile, MockNote } from "./ui";
import { Splash, Onboarding, HomeScreen, TerminalScreen, TabsScreen, HistoryScreen } from "./screens-core";
import { ExplorerScreen, PreviewScreen, EditorScreen, ProjectsScreen } from "./screens-files";
import { PackagesScreen, PkgDetailScreen, LinuxScreen, NetworkScreen, SshScreen, MonitorScreen } from "./screens-sys";

function Apps() {
  const items: [typeof Home, string, ScreenId][] = [[Code2, "Studio", "editor"], [Box, "Linux", "linux"], [Network, "Network", "network"], [KeyRound, "SSH", "ssh"], [Cpu, "Monitor", "monitor"], [FolderOpen, "Projects", "projects"]];
  return <NavCtx.Consumer>{({ go }) => <div><div className="grid grid-cols-4 gap-y-5">{items.map(([I, l, s], i) => <AppTile key={l} icon={I} label={l} delay={i * 40} onClick={() => go(s)} />)}</div><MockNote text="More screens (AI, plugins, browser, settings…) coming next" /></div>}</NavCtx.Consumer>;
}
const map: Partial<Record<ScreenId, () => React.ReactNode>> = {
  home: HomeScreen, terminal: TerminalScreen, tabs: TabsScreen, history: HistoryScreen, explorer: ExplorerScreen, preview: PreviewScreen,
  editor: EditorScreen, projects: ProjectsScreen, packages: PackagesScreen, pkg: PkgDetailScreen, linux: LinuxScreen, network: NetworkScreen,
  ssh: SshScreen, monitor: MonitorScreen, apps: Apps,
};
const tabs: [typeof Home, string, ScreenId][] = [[Home, "Home", "home"], [TerminalSquare, "Terminal", "terminal"], [FolderOpen, "Files", "explorer"], [Package, "Packages", "packages"], [Grid2x2, "Apps", "apps"]];

export function NexusApp() {
  const [stage, setStage] = useState<"splash" | "onboard" | "app">("splash");
  const [stack, setStack] = useState<{ s: ScreenId; p?: string }[]>([{ s: "home" }]);
  const [reduce, setReduce] = useState(false);
  const cur = stack[stack.length - 1]!;
  const go = (s: ScreenId, p?: string) => setStack((st) => (tabs.some((t) => t[2] === s) ? [{ s }] : [...st, p === undefined ? { s } : { s, p }]));
  const back = () => setStack((st) => (st.length > 1 ? st.slice(0, -1) : st));
  const Screen = map[cur.s] ?? HomeScreen;
  return (
    <NavCtx.Provider value={{ go, back, ...(cur.p !== undefined ? { param: cur.p } : {}), reduce, setReduce }}>
      <div className={cn("relative mx-auto min-h-screen max-w-md bg-background pb-32 font-sans", reduce && "reduce-motion")}>
        {stage === "splash" && <Splash onDone={() => setStage("onboard")} />}
        {stage === "onboard" && <Onboarding onDone={() => setStage("app")} />}
        <header className="glass sticky top-0 z-20 flex items-center gap-3 border-b border-border px-5 py-3">
          <span className="ember-flow flex h-9 w-9 items-center justify-center rounded-xl shadow-glow"><TerminalSquare className="h-5 w-5 text-primary-foreground" /></span>
          <div><p className="text-sm font-bold tracking-[0.2em]">NEXUS</p><p className="font-mono text-[10px] text-primary">TERMINAL</p></div>
        </header>
        <main key={cur.s + (cur.p ?? "")} className="screen-in px-5 pt-5"><Screen /></main>
        <nav className="glass fixed inset-x-4 bottom-4 z-30 mx-auto flex max-w-[calc(28rem-2rem)] justify-between rounded-full border border-border p-1.5">
          {tabs.map(([I, l, s]) => (
            <button key={s} aria-label={l} onClick={() => go(s)} className={cn("press flex h-12 items-center gap-2 rounded-full px-3 text-xs transition-all", stack[0]!.s === s ? "bg-primary/15 text-primary" : "text-muted-foreground")}>
              <I className="h-5 w-5" />{stack[0]!.s === s && <span className="font-medium">{l}</span>}
            </button>
          ))}
        </nav>
      </div>
    </NavCtx.Provider>
  );
}
