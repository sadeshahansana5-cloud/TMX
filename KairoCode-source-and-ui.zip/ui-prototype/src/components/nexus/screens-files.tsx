import { useState } from "react";
import { Folder, FileText, FileCode, FileArchive, Image, LayoutGrid, List, Plus, Search, Eye, EyeOff, Share2, Copy, Scissors, Trash2, Pencil, Play, Save, Bug, ChevronRight, Lock, FolderPlus, Check } from "lucide-react";
import { cn } from "@/lib/utils";
import { Card, Pill, IconBtn, Btn, Group, Row, Progress, useNav, SubHeader, Chips, MockNote, inputCls } from "./ui";

const files = [
  { n: "projects", k: "dir", s: "12 items", p: "drwxr-xr-x" },
  { n: "scripts", k: "dir", s: "8 items", p: "drwxr-xr-x" },
  { n: "backups", k: "dir", s: "3 items", p: "drwx------" },
  { n: ".config", k: "dir", s: "21 items", p: "drwxr-xr-x", h: true },
  { n: "main.py", k: "code", s: "4.2 KB", p: "-rw-r--r--" },
  { n: "notes.md", k: "text", s: "1.1 KB", p: "-rw-r--r--" },
  { n: "site.tar.gz", k: "zip", s: "18 MB", p: "-rw-r--r--" },
  { n: "screenshot.png", k: "img", s: "640 KB", p: "-rw-r--r--" },
  { n: ".zshrc", k: "text", s: "2 KB", p: "-rw-r--r--", h: true },
] as const;
const icons = { dir: Folder, code: FileCode, text: FileText, zip: FileArchive, img: Image };

export function ExplorerScreen() {
  const { go } = useNav();
  const [grid, setGrid] = useState(false);
  const [hidden, setHidden] = useState(false);
  const [root, setRoot] = useState("Home");
  const [q, setQ] = useState("");
  const [sel, setSel] = useState<Set<string>>(new Set());
  const list = files.filter((f) => (hidden || !("h" in f)) && f.n.includes(q));
  const toggle = (n: string) => setSel((s) => { const x = new Set(s); x.has(n) ? x.delete(n) : x.add(n); return x; });
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <div className="relative flex-1"><Search className="absolute left-4 top-4 h-4 w-4 text-muted-foreground" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search files…" className={cn(inputCls, "pl-10")} /></div>
        <IconBtn icon={grid ? List : LayoutGrid} label="Layout" onClick={() => setGrid(!grid)} />
        <IconBtn icon={hidden ? EyeOff : Eye} label="Hidden files" active={hidden} onClick={() => setHidden(!hidden)} />
      </div>
      <Chips items={["Home", "Shared storage", "Debian root"]} value={root} onChange={setRoot} />
      <p className="font-mono text-xs text-muted-foreground">{root === "Home" ? "/data/data/com.nexus/files/home" : root === "Shared storage" ? "/storage/emulated/0" : "/proot/debian"}</p>
      <Card className="p-3">
        <div className="mb-2 flex justify-between text-xs"><span>Storage</span><span className="font-mono text-muted-foreground">45.2 / 64 GB</span></div>
        <Progress value={71} />
      </Card>
      {sel.size > 0 && (
        <div className="rise flex items-center gap-2 rounded-3xl border border-primary/30 bg-accent p-2">
          <span className="flex-1 pl-2 text-sm text-accent-foreground">{sel.size} selected</span>
          {[Copy, Scissors, Pencil, Share2, FileArchive, Trash2].map((I, i) => <IconBtn key={i} icon={I} size="sm" label="action" />)}
        </div>
      )}
      <div className={cn(grid ? "grid grid-cols-3 gap-3" : "divide-y divide-border overflow-hidden rounded-3xl border border-border bg-card/80")}>
        {list.map((f, i) => {
          const I = icons[f.k];
          const open = () => (f.k === "dir" ? null : f.k === "code" ? go("editor") : go("preview", f.n));
          return grid ? (
            <button key={f.n} onClick={open} onContextMenu={(e) => { e.preventDefault(); toggle(f.n); }} style={{ animationDelay: `${i * 30}ms` }}
              className={cn("rise press flex flex-col items-center gap-2 rounded-3xl border border-border bg-card/80 p-3", sel.has(f.n) && "border-primary")}>
              <span className="ios-tile flex h-12 w-12 items-center justify-center text-primary"><I className="h-6 w-6" /></span>
              <span className="w-full truncate text-center text-xs">{f.n}</span>
            </button>
          ) : (
            <div key={f.n} className="flex items-center">
              <button aria-label="Select" onClick={() => toggle(f.n)} className={cn("ml-4 flex h-6 w-6 items-center justify-center rounded-full border transition", sel.has(f.n) ? "border-primary bg-primary text-primary-foreground" : "border-border")}>
                {sel.has(f.n) && <Check className="h-3.5 w-3.5" />}
              </button>
              <Row icon={I} title={f.n} sub={`${f.s} · ${f.p}`} onClick={open} right={f.k === "dir" ? <ChevronRight className="h-4 w-4 text-muted-foreground" /> : undefined} />
            </div>
          );
        })}
      </div>
      <div className="flex gap-2"><Btn variant="glass" className="flex-1"><Plus className="h-4 w-4" />New file</Btn><Btn variant="glass" className="flex-1"><FolderPlus className="h-4 w-4" />New folder</Btn></div>
      <MockNote />
    </div>
  );
}

export function PreviewScreen() {
  const { param, go } = useNav();
  const n = param ?? "notes.md";
  return (
    <div className="space-y-4">
      <SubHeader title={n} right={<IconBtn icon={Share2} label="Share" />} />
      <Card className="font-mono text-xs leading-relaxed text-muted-foreground">
        {n.endsWith(".png") ? <div className="orb mx-auto h-48 w-48 rounded-full" /> : n.endsWith(".gz") ? (
          <>{["site/index.html", "site/style.css", "site/app.js", "site/assets/logo.svg"].map((x) => <p key={x}>📄 {x}</p>)}</>
        ) : (
          <><p className="text-primary"># Notes</p><p>- setup ssh keys for vps</p><p>- pkg install postgresql</p><p>- finish telegram bot handlers</p></>
        )}
      </Card>
      <Group title="Info">
        <Row title="Path" sub={`~/${n}`} /><Row title="Size" sub="1.1 KB" /><Row icon={Lock} title="Permissions" sub="-rw-r--r-- · owner u0_a312" /><Row title="Modified" sub="Nov 24, 2026 · 15:41" />
      </Group>
      <div className="grid grid-cols-2 gap-2">
        {n.endsWith(".gz") ? <Btn className="col-span-2">Extract here</Btn> : <Btn onClick={() => go("editor")} className="col-span-2"><Pencil className="h-4 w-4" />Open in editor</Btn>}
        <Btn variant="glass">Rename</Btn><Btn variant="danger">Delete</Btn>
      </div>
    </div>
  );
}

const code = `import os
from telegram.ext import Application

TOKEN = os.getenv("BOT_TOKEN")

def main():
    app = Application.builder().token(TOKEN).build()
    print("bot running…")
    app.run_polling()

if __name__ == "__main__":
    main()`;
const kw = new Set(["import", "from", "def", "if", "return", "print", "for", "in", "as", "class"]);
function highlight(line: string) {
  const parts = line.split(/(".*?"|#.*$|\b(?:import|from|def|if|return|print|for|in|as|class)\b)/g);
  return parts.map((p, i) => <span key={i} className={p.startsWith('"') ? "text-success" : p.startsWith("#") ? "text-muted-foreground" : kw.has(p) ? "text-primary" : ""}>{p}</span>);
}
export function EditorScreen() {
  const [lang, setLang] = useState("Python");
  const [out, setOut] = useState<string | null>(null);
  const [tab, setTab] = useState("Code");
  return (
    <div className="space-y-4">
      <SubHeader title="Code Studio" right={<IconBtn icon={Save} label="Save" />} />
      <Chips items={["Python", "JavaScript", "Node.js", "C", "C++", "Java", "PHP", "Ruby", "Go", "Rust", "HTML", "CSS"]} value={lang} onChange={setLang} />
      <Chips items={["Code", "Snippets", "Templates"]} value={tab} onChange={setTab} />
      {tab === "Code" ? (
        <div className="overflow-hidden rounded-3xl border border-border bg-background">
          <div className="flex items-center gap-2 border-b border-border bg-card px-4 py-2.5"><span className="h-3 w-3 rounded-full bg-destructive" /><span className="h-3 w-3 rounded-full bg-chart-5" /><span className="h-3 w-3 rounded-full bg-success" /><span className="ml-2 font-mono text-xs text-muted-foreground">tgbot/main.py</span></div>
          <pre className="overflow-x-auto p-3 font-mono text-[12px] leading-relaxed">
            {code.split("\n").map((l, i) => <div key={i}><span className="mr-3 inline-block w-5 text-right text-muted-foreground/50">{i + 1}</span>{highlight(l)}</div>)}
          </pre>
        </div>
      ) : (
        <Group>{(tab === "Snippets" ? ["Flask hello world", "Read JSON file", "Async HTTP fetch", "argparse CLI"] : ["Python CLI", "Node Express API", "Static website", "C++ console app"]).map((s) => <Row key={s} icon={FileCode} title={s} sub={lang} right={<Plus className="h-4 w-4 text-primary" />} />)}</Group>
      )}
      <div className="flex gap-2">
        <Btn className="flex-1" onClick={() => setOut("ok")}><Play className="h-4 w-4" />Run</Btn>
        <Btn variant="glass" className="flex-1" onClick={() => setOut("err")}><Bug className="h-4 w-4" />Debug</Btn>
      </div>
      {out && (
        <Card className="font-mono text-xs">
          {out === "ok" ? <><p className="text-primary">$ python3 main.py</p><p className="text-success">bot running…</p><p className="text-muted-foreground">[mock] requires python runtime: pkg install python</p></>
            : <><p className="text-destructive">KeyError: 'BOT_TOKEN'</p><p className="text-muted-foreground">  File "main.py", line 4</p><p className="mt-2 text-accent-foreground">💡 Set BOT_TOKEN in Settings → Environment</p></>}
        </Card>
      )}
      <Group title="Package managers"><Row icon={FileCode} title="pip" sub="python-telegram-bot 21.3 · requests 2.32" right={<Pill status="Installed" />} /><Row icon={FileCode} title="npm" sub="express 4.19 · nodemon 3.1" right={<Pill status="Installed" />} /></Group>
      <MockNote text="Running code requires installed runtimes — prototype output" />
    </div>
  );
}

export function ProjectsScreen() {
  const { go } = useNav();
  const ps = [["telegram-bot", "Python", 82, "2h ago"], ["portfolio-site", "HTML", 100, "yesterday"], ["api-server", "Node.js", 60, "3d ago"], ["rust-cli", "Rust", 25, "1w ago"]] as const;
  return (
    <div className="space-y-4">
      <SubHeader title="Projects" right={<IconBtn icon={Plus} label="New" active />} />
      {ps.map(([n, l, p, t], i) => (
        <Card key={n} delay={i * 60} onClick={() => go("editor")}>
          <div className="flex items-center gap-3">
            <span className="ios-tile flex h-11 w-11 items-center justify-center text-primary"><Folder className="h-5 w-5" /></span>
            <div className="flex-1"><p className="font-semibold">{n}</p><p className="font-mono text-[11px] text-muted-foreground">{l} · {t}</p></div>
            <Pill status={p === 100 ? "Active" : "Ready"} label={`${p}%`} />
          </div>
          <Progress value={p} className="mt-3" />
        </Card>
      ))}
    </div>
  );
}
