import { useEffect, useRef, useState } from "react";
import {
  TerminalSquare, Cpu, MemoryStick, HardDrive, FolderOpen, Package, Bot, Zap, Bell, Play, Plus, X,
  Columns2, Maximize2, Search, Download, Copy, Star, History as HistoryIcon, Code2, Network, Shield,
  ChevronRight, Sparkles, Clock, Trash2, Minus,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Card, Pill, IconBtn, AppTile, Btn, Group, Row, Progress, Ring, Spark, useWander, useNav, SubHeader, Chips, MockNote, inputCls } from "./ui";

/* ---------- Splash ---------- */
export function Splash({ onDone }: { onDone: () => void }) {
  const [p, setP] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setP((x) => (x >= 100 ? 100 : x + 4)), 60);
    const d = setTimeout(onDone, 2000);
    return () => { clearInterval(t); clearTimeout(d); };
  }, [onDone]);
  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center overflow-hidden bg-background">
      <Particles />
      <div className="logo-glow ember-flow flex h-24 w-24 items-center justify-center rounded-[28%] shadow-glow">
        <TerminalSquare className="h-12 w-12 text-primary-foreground" />
      </div>
      <h1 className="rise mt-6 text-3xl font-bold tracking-[0.25em]" style={{ animationDelay: "200ms" }}>NEXUS</h1>
      <p className="rise font-mono text-xs tracking-[0.4em] text-primary" style={{ animationDelay: "350ms" }}>TERMINAL</p>
      <div className="mt-10 w-40"><Progress value={p} /></div>
      <p className="mt-3 font-mono text-[10px] text-muted-foreground">booting environment… {p}%</p>
    </div>
  );
}

export function Particles({ n = 18 }: { n?: number }) {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {Array.from({ length: n }).map((_, i) => (
        <span key={i} className="particle absolute bottom-0 rounded-full bg-primary"
          style={{ left: `${(i * 53) % 100}%`, width: 2 + (i % 3), height: 2 + (i % 3), animationDuration: `${6 + (i % 5) * 2}s`, animationDelay: `${(i % 7) * 0.8}s`, opacity: 0.6 }} />
      ))}
    </div>
  );
}

/* ---------- Onboarding ---------- */
const slides = [
  { icon: TerminalSquare, t: "A terminal, reimagined", d: "Tabs, split panes, history and smart suggestions on top of the Termux engine." },
  { icon: Code2, t: "Your pocket dev studio", d: "Edit code, manage packages, files, SSH and databases — all in one place." },
  { icon: Bot, t: "AI that asks first", d: "Generate and explain commands. Nothing runs without your approval." },
];
export function Onboarding({ onDone }: { onDone: () => void }) {
  const [i, setI] = useState(0);
  const s = slides[i]!;
  return (
    <div className="fixed inset-0 z-40 mx-auto flex max-w-md flex-col bg-background px-6 pb-10 pt-16">
      <Particles n={10} />
      <button onClick={onDone} className="self-end text-sm text-muted-foreground">Skip</button>
      <div key={i} className="screen-in flex flex-1 flex-col items-center justify-center text-center">
        <div className="relative mb-10 flex h-44 w-44 items-center justify-center">
          <div className="orb absolute inset-0 rounded-full opacity-60" />
          <div className="ios-tile relative flex h-24 w-24 items-center justify-center text-primary"><s.icon className="h-11 w-11" /></div>
        </div>
        <h2 className="text-2xl font-semibold">{s.t}</h2>
        <p className="mt-3 max-w-xs text-sm text-muted-foreground">{s.d}</p>
      </div>
      <div className="mb-6 flex justify-center gap-2">
        {slides.map((_, k) => <span key={k} className={cn("h-2 rounded-full transition-all duration-500", k === i ? "w-8 bg-primary" : "w-2 bg-secondary")} />)}
      </div>
      <Btn onClick={() => (i < 2 ? setI(i + 1) : onDone())} className="w-full">{i < 2 ? "Continue" : "Get started"}</Btn>
    </div>
  );
}

/* ---------- Home ---------- */
export function HomeScreen() {
  const { go } = useNav();
  const cpu = useWander(34), ram = useWander(58, 40, 80), sto = 71;
  const quick = [
    { icon: TerminalSquare, l: "Terminal", s: "terminal" as const, a: true },
    { icon: FolderOpen, l: "Explorer", s: "explorer" as const },
    { icon: Package, l: "Packages", s: "packages" as const },
    { icon: Code2, l: "Studio", s: "editor" as const },
    { icon: Network, l: "Network", s: "network" as const },
    { icon: Bot, l: "AI", s: "ai" as const },
    { icon: Shield, l: "Security", s: "security" as const },
    { icon: Sparkles, l: "All apps", s: "apps" as const },
  ];
  return (
    <div className="space-y-5">
      <Card className="relative overflow-hidden">
        <div className="orb absolute -right-12 -top-12 h-44 w-44 rounded-full opacity-80" />
        <p className="text-xs text-muted-foreground">Good evening, Sadesha</p>
        <h2 className="mt-1 text-2xl font-semibold">Environment <span className="text-primary">ready</span></h2>
        <p className="mt-1 font-mono text-[11px] text-muted-foreground">bash 5.2 · debian-proot · aarch64</p>
        <div className="mt-5 flex justify-between">
          <Ring value={cpu} label="CPU" /><Ring value={ram} label="RAM" /><Ring value={sto} label="Storage" />
        </div>
      </Card>

      <div className="grid grid-cols-4 gap-y-4">
        {quick.map((q, i) => <AppTile key={q.l} icon={q.icon} label={q.l} accent={q.a} delay={80 + i * 40} onClick={() => go(q.s)} />)}
      </div>

      <Card delay={150} onClick={() => go("ai")} className="flex items-center gap-3 border-primary/30">
        <span className="ember-flow flex h-11 w-11 items-center justify-center rounded-2xl"><Bot className="h-5 w-5 text-primary-foreground" /></span>
        <div className="flex-1"><p className="text-sm font-semibold">Ask NEXUS AI</p><p className="text-xs text-muted-foreground">"Find files larger than 100MB"</p></div>
        <ChevronRight className="h-5 w-5 text-muted-foreground" />
      </Card>

      <Group title="Active sessions" delay={200}>
        {[["zsh — ~/projects/api", "node server.js · 2h 14m"], ["bash — debian", "apt upgrade · running"]].map(([t, s], i) => (
          <Row key={t} icon={TerminalSquare} title={t!} sub={s} onClick={() => go("terminal")} right={<Pill status={i ? "Running" : "Active"} />} />
        ))}
      </Group>

      <Card delay={250}>
        <div className="flex items-center justify-between"><p className="text-sm font-semibold">Commands this week</p><span className="text-xs text-success">+18%</span></div>
        <Spark pts={[12, 18, 14, 26, 22, 34, 30, 42, 38, 52, 48, 60]} />
      </Card>

      <Group title="Recent projects" delay={300}>
        {[["portfolio-site", "~/projects/portfolio · HTML"], ["telegram-bot", "~/projects/tgbot · Python"], ["api-server", "~/projects/api · Node.js"]].map(([t, s]) => (
          <Row key={t} icon={Code2} title={t!} sub={s} onClick={() => go("projects")} right={<ChevronRight className="h-4 w-4 text-muted-foreground" />} />
        ))}
      </Group>

      <Group title="Recently installed" delay={350}>
        {[["python", "3.12.4"], ["git", "2.45.2"], ["neovim", "0.10.0"]].map(([t, v]) => (
          <Row key={t} icon={Package} title={t!} sub={`v${v}`} onClick={() => go("pkg", t)} right={<Pill status="Installed" />} />
        ))}
      </Group>

      <Group title="Quick commands" delay={400}>
        <div className="no-scrollbar flex gap-2 overflow-x-auto p-3">
          {["pkg update", "ls -la", "git pull", "htop", "python main.py"].map((c) => (
            <button key={c} onClick={() => go("terminal")} className="ios-btn shrink-0 rounded-full px-4 py-2 font-mono text-xs"><Zap className="mr-1 inline h-3 w-3 text-primary" />{c}</button>
          ))}
        </div>
      </Group>

      <Group title="Environment" delay={450}>
        <Row icon={Cpu} title="Termux engine" sub="0.118.1 · integration pending" right={<Pill status="Mock" />} />
        <Row icon={MemoryStick} title="PRoot Debian" sub="bookworm · 1.2 GB" right={<Pill status="Online" />} />
        <Row icon={HardDrive} title="Shared storage" sub="/sdcard · granted" right={<Pill status="Active" />} />
        <Row icon={Bell} title="Notifications" sub="3 unread" onClick={() => go("notifications")} right={<ChevronRight className="h-4 w-4 text-muted-foreground" />} />
      </Group>
      <MockNote />
    </div>
  );
}

/* ---------- Terminal ---------- */
const suggestions = ["ls -la", "ls --color=auto", "git status", "git commit -m", "pkg install", "python3 -m http.server", "cd ~/projects", "neofetch"];
type Line = { t: "cmd" | "out" | "ok" | "err"; s: string };
const boot: Line[] = [
  { t: "out", s: "Welcome to NEXUS TERMINAL (prototype)" },
  { t: "cmd", s: "neofetch --off" },
  { t: "out", s: "OS: Android 14 aarch64 · Shell: zsh 5.9" },
  { t: "out", s: "Packages: 214 (dpkg) · Memory: 3.1G / 7.6G" },
];
function respond(cmd: string): Line[] {
  const c = cmd.trim().split(" ")[0];
  if (c === "ls") return [{ t: "out", s: "projects/  scripts/  backups/  .zshrc  notes.md" }];
  if (c === "git") return [{ t: "out", s: "On branch main · nothing to commit, working tree clean" }];
  if (c === "rm") return [{ t: "err", s: "blocked in prototype: destructive commands are not simulated" }];
  if (c === "clear") return [];
  return [{ t: "ok", s: `[mock] '${c}' would run via the Termux engine` }];
}
export function TerminalScreen() {
  const { go } = useNav();
  const [tabs, setTabs] = useState(["zsh", "debian", "node"]);
  const [act, setAct] = useState(0);
  const [split, setSplit] = useState(false);
  const [full, setFull] = useState(false);
  const [font, setFont] = useState(12);
  const [lines, setLines] = useState<Line[]>(boot);
  const [cmd, setCmd] = useState("");
  const [find, setFind] = useState("");
  const [typing, setTyping] = useState(false);
  const end = useRef<HTMLDivElement>(null);
  useEffect(() => { end.current?.scrollIntoView({ block: "nearest" }); }, [lines]);
  const sugg = cmd ? suggestions.filter((s) => s.startsWith(cmd) && s !== cmd).slice(0, 3) : [];
  const run = (c: string) => {
    if (!c.trim()) return;
    setCmd(""); setTyping(true);
    setLines((l) => [...l, { t: "cmd", s: c }]);
    setTimeout(() => { setTyping(false); setLines((l) => (c === "clear" ? [] : [...l, ...respond(c)])); }, 500);
  };
  const color = { cmd: "text-primary", out: "text-muted-foreground", ok: "text-success", err: "text-destructive" };
  const hl = (s: string) => (find && s.toLowerCase().includes(find.toLowerCase()) ? "bg-primary/25 rounded" : "");
  const pane = (
    <div className="flex-1 overflow-y-auto p-3 font-mono leading-relaxed" style={{ fontSize: font }}>
      {lines.map((l, i) => (
        <p key={i} className={cn("rise", color[l.t], hl(l.s))} style={{ animationDuration: "0.3s" }}>
          {l.t === "cmd" ? <><span className="text-success">sadesha@nexus</span><span className="text-muted-foreground">:~$ </span><span className="text-foreground">{l.s}</span></> : l.s}
        </p>
      ))}
      {typing && <p className="text-muted-foreground">⠋ running…</p>}
      <p className="text-primary">$ <span className="caret">▋</span></p>
      <div ref={end} />
    </div>
  );
  return (
    <div className={cn("space-y-3", full && "fixed inset-0 z-50 bg-background p-3")}>
      <div className="no-scrollbar flex items-center gap-2 overflow-x-auto">
        {tabs.map((t, i) => (
          <button key={t + i} onClick={() => setAct(i)} className={cn("press flex shrink-0 items-center gap-2 rounded-full px-3 py-2 font-mono text-xs", i === act ? "bg-ember text-primary-foreground shadow-glow" : "ios-btn")}>
            {t}{tabs.length > 1 && <X className="h-3 w-3" onClick={(e) => { e.stopPropagation(); setTabs(tabs.filter((_, k) => k !== i)); setAct(0); }} />}
          </button>
        ))}
        <IconBtn icon={Plus} size="sm" label="New tab" onClick={() => { setTabs([...tabs, `sh-${tabs.length + 1}`]); setAct(tabs.length); }} />
      </div>
      <div className="flex gap-2">
        <IconBtn icon={Columns2} size="sm" label="Split" active={split} onClick={() => setSplit(!split)} />
        <IconBtn icon={Maximize2} size="sm" label="Full screen" active={full} onClick={() => setFull(!full)} />
        <IconBtn icon={Minus} size="sm" label="Smaller font" onClick={() => setFont(Math.max(9, font - 1))} />
        <IconBtn icon={Plus} size="sm" label="Bigger font" onClick={() => setFont(Math.min(18, font + 1))} />
        <IconBtn icon={Copy} size="sm" label="Copy output" onClick={() => navigator.clipboard?.writeText(lines.map((l) => l.s).join("\n"))} />
        <IconBtn icon={Download} size="sm" label="Export logs" />
        <IconBtn icon={HistoryIcon} size="sm" label="History" onClick={() => go("history")} />
        <IconBtn icon={TerminalSquare} size="sm" label="Tab manager" onClick={() => go("tabs")} />
      </div>
      <div className="relative">
        <Search className="absolute left-4 top-3.5 h-4 w-4 text-muted-foreground" />
        <input value={find} onChange={(e) => setFind(e.target.value)} placeholder="Search output…" className={cn(inputCls, "h-11 pl-10")} />
      </div>
      <div className={cn("flex overflow-hidden rounded-3xl border border-border bg-background", full ? "h-[60vh]" : "h-[44vh]", split && "flex-col divide-y divide-border")}>
        {pane}
        {split && <div className="flex-1 p-3 font-mono text-muted-foreground" style={{ fontSize: font }}><p className="text-primary">debian:~# top -b -n1</p><p>PID USER  %CPU %MEM COMMAND</p><p>412 root   3.1  1.2 node</p><p>118 root   0.4  0.6 sshd</p></div>}
      </div>
      {sugg.length > 0 && (
        <div className="flex gap-2">{sugg.map((s) => <button key={s} onClick={() => setCmd(s)} className="ios-btn rise rounded-full px-3 py-1.5 font-mono text-xs text-primary">{s}</button>)}</div>
      )}
      <form onSubmit={(e) => { e.preventDefault(); run(cmd); }} className="flex gap-2">
        <input value={cmd} onChange={(e) => setCmd(e.target.value)} placeholder="Type a command…" className={inputCls} autoCapitalize="off" />
        <button aria-label="Run" className="press flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-ember text-primary-foreground shadow-glow"><Play className="h-5 w-5" /></button>
      </form>
      <div className="grid grid-cols-6 gap-1.5">
        {["ESC", "TAB", "CTRL", "ALT", "↑", "↓", "/", "-", "|", "~", "←", "→"].map((k) => (
          <button key={k} onClick={() => k.length === 1 && setCmd(cmd + k)} className="ios-btn h-10 rounded-xl font-mono text-[11px]">{k}</button>
        ))}
      </div>
      {full && <Btn variant="glass" className="w-full" onClick={() => setFull(false)}>Exit full screen</Btn>}
    </div>
  );
}

export function TabsScreen() {
  const { go } = useNav();
  const sessions = [
    { n: "zsh", p: "~/projects/api", s: "Active" as const, t: "2h 14m" },
    { n: "debian", p: "/root", s: "Running" as const, t: "41m" },
    { n: "node", p: "~/projects/api", s: "Running" as const, t: "2h 10m" },
    { n: "ssh vps", p: "ubuntu@203.0.113.7", s: "Ready" as const, t: "restorable" },
  ];
  return (
    <div className="space-y-4">
      <SubHeader title="Sessions" right={<IconBtn icon={Plus} label="New session" active onClick={() => go("terminal")} />} />
      <div className="grid grid-cols-2 gap-3">
        {sessions.map((s, i) => (
          <Card key={s.n} delay={i * 60} onClick={() => go("terminal")} className="p-3">
            <div className="mb-3 h-20 overflow-hidden rounded-2xl bg-background p-2 font-mono text-[9px] text-muted-foreground"><p className="text-primary">$ {s.n}</p><p>{s.p}</p><p className="caret">▋</p></div>
            <div className="flex items-center justify-between"><p className="font-mono text-sm font-semibold">{s.n}</p><Pill status={s.s} /></div>
            <p className="mt-1 text-[11px] text-muted-foreground"><Clock className="mr-1 inline h-3 w-3" />{s.t}</p>
          </Card>
        ))}
      </div>
      <Group title="Profiles">
        {["Default · zsh · JetBrains Mono 12", "Root · debian proot", "Remote · ssh"].map((p) => <Row key={p} icon={TerminalSquare} title={p} right={<ChevronRight className="h-4 w-4 text-muted-foreground" />} />)}
      </Group>
    </div>
  );
}

export function HistoryScreen() {
  const [q, setQ] = useState("");
  const [f, setF] = useState("All");
  const [fav, setFav] = useState<Set<string>>(new Set(["git pull origin main"]));
  const items = [
    ["git pull origin main", "2m ago", 0], ["pkg install nodejs", "14m ago", 0], ["python3 bot.py", "1h ago", 1],
    ["ssh ubuntu@203.0.113.7", "3h ago", 0], ["tar -xzf backup.tar.gz", "yesterday", 0], ["npm run build", "yesterday", 0],
  ] as const;
  const list = items.filter(([c]) => c.includes(q) && (f !== "Favorites" || fav.has(c)) && (f !== "Failed" || items.find((x) => x[0] === c)![2]));
  return (
    <div className="space-y-4">
      <SubHeader title="Command history" right={<IconBtn icon={Trash2} label="Clear" />} />
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search history…" className={inputCls} />
      <Chips items={["All", "Favorites", "Failed"]} value={f} onChange={setF} />
      <Group>
        {list.map(([c, t, e]) => (
          <Row key={c} title={c} sub={t} right={
            <div className="flex items-center gap-2">
              {e ? <Pill status="Failed" /> : null}
              <button aria-label="Favorite" onClick={() => setFav((s) => { const n = new Set(s); n.has(c) ? n.delete(c) : n.add(c); return n; })}>
                <Star className={cn("h-4 w-4 transition", fav.has(c) ? "fill-primary text-primary scale-110" : "text-muted-foreground")} />
              </button>
            </div>} />
        ))}
      </Group>
    </div>
  );
}
