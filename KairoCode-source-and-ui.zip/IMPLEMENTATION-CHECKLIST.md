# Kairo Code — implementation checklist and integration notes

## Decisions locked from the user's instructions

- Display name: **Kairo Code**.
- Android application ID / namespace stays **`com.termux`**. No package-name migration and no custom bootstrap variant.
- Keep the official Termux engine, session service, terminal emulator, package-manager integration, and `apt-android-7` bootstrap selection.
- Visual direction: Obsidian black with vivid orange as the primary accent. Terminal output uses meaningful ANSI colors, not indiscriminate rainbow styling.
- Preserve the Termux logo mark/identity while adapting the surrounding treatment to Kairo Code's black/orange palette; do not replace it with unrelated Nexus branding.
- Preserve GPLv3-only and all applicable third-party notices.

## What the supplied files actually contain

- `termux-app-master(2).zip` is the Termux Android app source. It has an existing functional terminal engine and Android Views-based UI. It is not a ready-made Kairo Code fork.
- `nexus-terminal-source(1).zip` is a Lovable/TanStack Start + React + TypeScript web UI prototype. Its screens include Home, Terminal, session/history, Explorer, preview/editor, projects, packages, Linux environment, network, SSH and system monitor.
- The prototype deliberately uses sample data and contains explicit mock notices. Examples: simulated package installation, fake ping/DNS output, simulated device metrics, static file/project lists, mock editor execution, mock saved SSH hosts. These must not be represented as working Android capabilities.
- The design prompt's early cyan/purple accents conflict with later, more specific black/orange directions. Use black/orange. “Nexus” and “Nexus Terminal” are prototype/prompt names; the app brand is Kairo Code.

## Integration approach

The Lovable React project cannot simply be copied into this Android app as native screens. Replacing the working terminal with a browser terminal or simulated command console would violate the instruction to keep Termux real. The implementation should keep the existing `TerminalView`, Termux sessions/service and keyboard path, then add Android-native surfaces that call real Termux APIs/filesystem only where those APIs exist. Prototype-only surfaces must be labelled as previews until backed by real operations. **Prototype build not verified:** archive has `bun.lock` but no `package-lock.json`; `npm ci` cannot run without an npm lockfile, and `npm install` terminated in npm with `Cannot read properties of null (reading 'edgesOut')`.

## Work status

- [x] Android launcher's displayed app name changed to Kairo Code through the Gradle manifest placeholder.
- [x] APK output prefix changed to `kairo-code_`.
- [x] GitHub Actions build workflow display name and artifact prefix changed to Kairo Code.
- [x] Package name left as `com.termux`.
- [x] Official bootstrap variant left as upstream `apt-android-7` default; no custom bootstrap work introduced.
- [x] Added a native Kairo Code workspace Activity reachable from the existing Termux session drawer; the original terminal Activity remains intact.
- [x] Added real `~/projects` creation with Empty, Python, Node.js, Static web and Bash templates.
- [x] Added real file browsing within Termux home, create file/folder, rename, confirmed delete, and UTF-8 text editing/saving for files up to 512 KiB.
- [x] Added project-terminal launch with the actual working directory, validated to stay within Termux home; existing shell sessions are created by Termux's terminal-session client.
- [x] Added symlink restrictions to the workspace browser and project directory.
- [ ] Build Android debug APK in an Android SDK/NDK-enabled CI environment and verify install/launch. **Local attempt blocked:** this sandbox has no `ANDROID_HOME`/SDK; Gradle wrapper starts but reports “SDK location not found”.
- [ ] Finish native screen design to match the supplied prototype more closely, including icon treatment, motion, tabbed editor, syntax support and responsive tablet layouts.
- [ ] Add file move/copy/multi-select/import/export/ZIP and shared-storage support with Android's storage access APIs.
- [ ] Add editor multi-tabs, find/replace, syntax support and real run/debug controls backed by installed Termux runtimes.
- [ ] Implement package browsing/install through the real `pkg`/APT environment and clearly show repository/permission failures.
- [ ] Implement Git operations against actual project directories and authenticated remotes; obtain explicit confirmation before push/destructive changes.
- [ ] Implement networking, SSH, Linux/PRoot, and system metrics only where supported by real tools/Android APIs; otherwise show unavailable or setup guidance.
- [ ] AI assistant only after an API is deliberately connected; generated shell commands require user review and confirmation before execution.
- [ ] Add security/privacy controls only with secure storage and tested Android authentication APIs.
- [ ] Add remaining screens (browser, download manager, database, plugins, notifications, security center, themes, onboarding) as real implementations or clearly marked nonfunctional previews—not fake live data.
- [ ] Update icon artwork preserving the Termux mark, then verify all launcher density/adaptive icon assets.
- [ ] Add automated tests for session handling, filesystem operations, destructive-action confirmation, and UI navigation.

## Build and distribution caveats

Because the package ID remains `com.termux`, Kairo Code cannot be installed side-by-side with an official Termux APK. Android also requires the signing key to match for an in-place update; a debug build signed with the repository's test key is not an official Termux update. Existing Termux plugins expect Termux package identity and may not identify the renamed launcher label. Do not distribute a release until its signing, licensing, bootstrap/repository compatibility and update path have been decided and tested.
