package com.termux.app.activities;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.termux.R;
import com.termux.app.TermuxActivity;
import com.termux.shared.termux.TermuxConstants;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Comparator;

/** Native Kairo Code project/file workspace. Terminal execution remains the Termux engine. */
public final class KairoWorkspaceActivity extends AppCompatActivity {
    private static final int BG = Color.rgb(9, 10, 15);
    private static final int CARD = Color.rgb(19, 21, 29);
    private static final int BORDER = Color.rgb(39, 42, 53);
    private static final int ORANGE = Color.rgb(255, 106, 0);
    private static final int TEXT = Color.rgb(239, 241, 246);
    private static final int MUTED = Color.rgb(151, 157, 171);
    private static final String EXTRA_PROJECT_DIR = "com.termux.KAIRO_PROJECT_DIRECTORY";

    private LinearLayout root;
    private LinearLayout body;
    private File currentDirectory;
    private File currentProject;

    @Override public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        currentDirectory = TermuxConstants.TERMUX_HOME_DIR;
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        showHome();
    }

    private void base(String title, String subtitle) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        TextView brand = text("KAIRO CODE", 12, ORANGE, true);
        brand.setLetterSpacing(0.18f);
        brand.setPadding(dp(20), dp(17), dp(20), dp(1));
        root.addView(brand);
        TextView heading = text(title, 25, TEXT, true);
        heading.setPadding(dp(20), dp(4), dp(20), 0);
        root.addView(heading);
        TextView hint = text(subtitle, 12, MUTED, false);
        hint.setPadding(dp(20), dp(5), dp(20), dp(14));
        root.addView(hint);
        ScrollView scroll = new ScrollView(this);
        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(16), dp(4), dp(16), dp(24));
        scroll.addView(body);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(8), dp(7), dp(8), dp(8));
        nav.setBackgroundColor(Color.rgb(16, 17, 23));
        String[] tabs = {"Home", "Projects", "Files", "Settings"};
        for (String tab : tabs) {
            TextView b = text(tab, 12, tab.equals(title) ? ORANGE : MUTED, true);
            b.setGravity(Gravity.CENTER);
            b.setPadding(dp(10), dp(12), dp(10), dp(12));
            b.setOnClickListener(v -> {
                if (tab.equals("Home")) showHome();
                else if (tab.equals("Projects")) showProjects();
                else if (tab.equals("Files")) { currentDirectory = TermuxConstants.TERMUX_HOME_DIR; showFiles(); }
                else showSettings();
            });
            nav.addView(b, new LinearLayout.LayoutParams(0, -2, 1));
        }
        root.addView(nav);
        setContentView(root);
    }

    private void showHome() {
        currentProject = null;
        base("Home", "Your Android development workspace · Termux-powered");
        card("REAL TERMUX TERMINAL", "Open a shell session without replacing the Termux terminal engine.", "Open terminal", () -> openTerminal(TermuxConstants.TERMUX_HOME_DIR));
        addGap();
        long free = TermuxConstants.TERMUX_HOME_DIR.getUsableSpace();
        card("WORKSPACE STORAGE", humanSize(free) + " available in the app's private filesystem.", "Browse files", () -> { currentDirectory = TermuxConstants.TERMUX_HOME_DIR; showFiles(); });
        addGap();
        File projects = projectsDir();
        File[] projectEntries = projects == null ? null : projects.listFiles();
        int count = projectEntries == null ? 0 : projectEntries.length;
        card("PROJECTS", count + " real project folder(s) in ~/projects.", "Manage projects", this::showProjects);
        addGap();
        card("PACKAGE MANAGER", "Use the real Termux pkg/apt environment; this shortcut does not simulate package installs.", "Open Termux shell", () -> openTerminal(TermuxConstants.TERMUX_HOME_DIR));
        addGap();
        TextView note = text("Kairo Code adds a native workspace around the original Termux shell. The screens here read and modify real files; platform-dependent features are not presented as live unless connected to a real API.", 12, MUTED, false);
        note.setPadding(dp(4), dp(6), dp(4), dp(12));
        body.addView(note);
    }

    private void showProjects() {
        base("Projects", "Projects are actual directories under ~/projects.");
        action("＋  New project", this::createProjectDialog);
        addGap();
        File projectRoot = projectsDir();
        File[] projects = projectRoot == null ? null : projectRoot.listFiles(f -> f.isDirectory() && isWithinHome(f) && !isSymlink(f));
        if (projects == null || projects.length == 0) {
            empty("No projects yet. Create one to make a real workspace folder.");
            return;
        }
        Arrays.sort(projects, Comparator.comparing(File::getName, String.CASE_INSENSITIVE_ORDER));
        for (File project : projects) {
            card(project.getName(), project.getAbsolutePath(), "Open terminal", () -> openTerminal(project));
            addGap();
            action("Open files · " + project.getName(), () -> { currentProject = project; currentDirectory = project; showFiles(); });
            addGap();
        }
    }

    private void createProjectDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        EditText name = new EditText(this);
        name.setSingleLine(true);
        name.setHint("Project name");
        name.setTextColor(TEXT);
        name.setHintTextColor(MUTED);
        box.addView(name);
        Spinner template = new Spinner(this);
        String[] choices = {"Empty", "Python", "Node.js", "Static web", "Bash"};
        template.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, choices));
        box.addView(template);
        new AlertDialog.Builder(this).setTitle("Create project").setView(box)
            .setNegativeButton("Cancel", null).setPositiveButton("Create", (d, w) -> {
                String n = name.getText().toString().trim();
                if (!n.matches("[A-Za-z0-9._-]{1,48}")) { toast("Use 1–48 letters, digits, dot, dash or underscore."); return; }
                File projectRoot = projectsDir();
                if (projectRoot == null) return;
                File dir = new File(projectRoot, n);
                if (dir.exists()) { toast("A project with that name already exists."); return; }
                if (!dir.mkdirs()) { toast("Could not create project folder."); return; }
                try { writeTemplate(dir, choices[template.getSelectedItemPosition()]); }
                catch (IOException e) { toast("Project folder created, but template failed: " + e.getMessage()); }
                currentProject = dir;
                currentDirectory = dir;
                showFiles();
            }).show();
    }

    private void writeTemplate(File dir, String template) throws IOException {
        if ("Python".equals(template)) write(new File(dir, "main.py"), "def main():\n    print('Hello from Kairo Code')\n\nif __name__ == '__main__':\n    main()\n");
        else if ("Node.js".equals(template)) {
            write(new File(dir, "package.json"), "{\n  \"name\": \"" + dir.getName() + "\",\n  \"version\": \"1.0.0\",\n  \"scripts\": {\"start\": \"node index.js\"}\n}\n");
            write(new File(dir, "index.js"), "console.log('Hello from Kairo Code');\n");
        } else if ("Static web".equals(template)) write(new File(dir, "index.html"), "<!doctype html>\n<html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"><title>Kairo project</title></head><body><h1>Hello from Kairo Code</h1></body></html>\n");
        else if ("Bash".equals(template)) write(new File(dir, "main.sh"), "#!/data/data/com.termux/files/usr/bin/bash\necho 'Hello from Kairo Code'\n");
        write(new File(dir, "README.md"), "# " + dir.getName() + "\n\nCreated in Kairo Code. Run commands in the Termux terminal after installing the required runtime.\n");
    }

    private void showFiles() {
        if (!isWithinHome(currentDirectory) || isSymlink(currentDirectory)) {
            currentDirectory = TermuxConstants.TERMUX_HOME_DIR;
            toast("That location is not available in the workspace file manager.");
        }
        String title = currentDirectory.equals(TermuxConstants.TERMUX_HOME_DIR) ? "Files" : currentDirectory.getName();
        base(title, currentDirectory.getAbsolutePath());
        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.HORIZONTAL);
        TextView file = actionView("＋ File", this::createFileDialog);
        TextView folder = actionView("＋ Folder", this::createFolderDialog);
        tools.addView(file, new LinearLayout.LayoutParams(0, -2, 1));
        tools.addView(folder, new LinearLayout.LayoutParams(0, -2, 1));
        body.addView(tools);
        if (!currentDirectory.equals(TermuxConstants.TERMUX_HOME_DIR)) {
            addGap();
            action("↑ Parent folder", () -> { File p = currentDirectory.getParentFile(); if (p != null && isWithinHome(p)) { currentDirectory = p; showFiles(); } });
        }
        addGap();
        File[] children = currentDirectory.listFiles();
        if (children == null) { empty("This folder cannot be read."); return; }
        Arrays.sort(children, Comparator.comparing((File f) -> !f.isDirectory()).thenComparing(File::getName, String.CASE_INSENSITIVE_ORDER));
        for (File item : children) {
            if (item.getName().startsWith(".")) continue;
            String meta = item.isDirectory() ? "Folder" : humanSize(item.length());
            card((item.isDirectory() ? "▰  " : "▤  ") + item.getName(), meta, item.isDirectory() ? "Open" : "Edit text", () -> {
                if (isSymlink(item)) { toast("Symbolic links are not browsed by the workspace file manager."); }
                else if (item.isDirectory()) { currentDirectory = item; showFiles(); }
                else editFile(item);
            });
            addGap();
            action("More · " + item.getName(), () -> fileActions(item));
            addGap();
        }
    }

    private void fileActions(File item) {
        if (isSymlink(item)) { toast("File actions are disabled for symbolic links."); return; }
        String[] actions = {"Rename", "Delete"};
        new AlertDialog.Builder(this).setTitle(item.getName()).setItems(actions, (d, which) -> {
            if (which == 0) renameDialog(item);
            else new AlertDialog.Builder(this).setTitle("Delete " + item.getName() + "?")
                .setMessage("This permanently deletes this item from the app's Termux home directory.")
                .setNegativeButton("Cancel", null).setPositiveButton("Delete", (di, w) -> {
                    if (deleteRecursively(item)) showFiles(); else toast("Delete failed.");
                }).show();
        }).show();
    }

    private void createFileDialog() { nameDialog("New file", name -> {
        File f = new File(currentDirectory, name);
        if (f.exists()) { toast("Already exists."); return; }
        try { if (f.createNewFile()) { editFile(f); } else toast("Could not create file."); }
        catch (IOException e) { toast("Create failed: " + e.getMessage()); }
    }); }
    private void createFolderDialog() { nameDialog("New folder", name -> {
        File f = new File(currentDirectory, name);
        if (f.exists()) { toast("Already exists."); return; }
        if (f.mkdir()) showFiles(); else toast("Could not create folder.");
    }); }
    private void renameDialog(File item) { nameDialog("Rename", name -> {
        if (!name.matches("[A-Za-z0-9._ -]{1,80}")) { toast("Invalid file name."); return; }
        File dest = new File(item.getParentFile(), name);
        if (dest.exists()) { toast("A file with that name already exists."); return; }
        if (item.renameTo(dest)) showFiles(); else toast("Rename failed.");
    }, item.getName()); }
    private interface NameAction { void run(String value); }
    private void nameDialog(String title, NameAction action) { nameDialog(title, action, ""); }
    private void nameDialog(String title, NameAction action, String initial) {
        EditText input = new EditText(this);
        input.setSingleLine(true); input.setText(initial); input.setHint("Name");
        new AlertDialog.Builder(this).setTitle(title).setView(input).setNegativeButton("Cancel", null)
            .setPositiveButton("Continue", (d, w) -> { String n = input.getText().toString().trim(); if (!n.isEmpty() && !n.contains("/") && !n.equals("..")) action.run(n); else toast("Enter a valid name."); }).show();
    }

    private void editFile(File file) {
        if (!isWithinHome(file) || !file.isFile()) { toast("Only regular files inside Termux home can be edited here."); return; }
        if (file.length() > 512 * 1024) { toast("This editor is for small text files (max 512 KB)."); return; }
        String content;
        try { content = read(file); }
        catch (IOException e) { toast("Could not read file: " + e.getMessage()); return; }
        base(file.getName(), file.getAbsolutePath());
        EditText editor = new EditText(this);
        editor.setGravity(Gravity.TOP | Gravity.START);
        editor.setTextColor(TEXT); editor.setHintTextColor(MUTED);
        editor.setTypeface(Typeface.MONOSPACE); editor.setTextSize(13);
        editor.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        editor.setBackground(round(CARD, BORDER, 16));
        editor.setPadding(dp(14), dp(12), dp(14), dp(12));
        editor.setText(content);
        body.addView(editor, new LinearLayout.LayoutParams(-1, dp(420)));
        addGap();
        action("Save file", () -> {
            try { write(file, editor.getText().toString()); toast("Saved " + file.getName()); }
            catch (IOException e) { toast("Save failed: " + e.getMessage()); }
        });
        addGap();
        action("Open Termux terminal", () -> openTerminal(currentProject == null ? file.getParentFile() : currentProject));
    }

    private void showSettings() {
        base("Settings", "Workspace preferences and existing Termux settings");
        card("Terminal keyboard", "The official Termux extra-key toolbar and real terminal keyboard remain available.", "Open Termux settings", () -> startActivity(new Intent(this, SettingsActivity.class)));
        addGap();
        card("Color identity", "Obsidian background · Kairo orange accent · original Termux app ID and bootstrap.", "About", () -> new AlertDialog.Builder(this).setTitle("Kairo Code")
            .setMessage("Based on Termux. Package name remains com.termux. This fork is not installable alongside the official Termux app and follows the upstream license.")
            .setPositiveButton(android.R.string.ok, null).show());
        addGap();
        card("Not connected yet", "AI, SSH profiles, package search GUI, live system telemetry, in-app browser and plugin marketplace are not falsely shown as working here.", "OK", () -> {});
    }

    private void openTerminal(File workingDirectory) {
        File target = workingDirectory != null && isWithinHome(workingDirectory) ? workingDirectory : TermuxConstants.TERMUX_HOME_DIR;
        Intent intent = TermuxActivity.newInstance(this);
        intent.putExtra(EXTRA_PROJECT_DIR, target.getAbsolutePath());
        startActivity(intent);
    }

    private File projectsDir() {
        File dir = new File(TermuxConstants.TERMUX_HOME_DIR, "projects");
        if (dir.exists() && (isSymlink(dir) || !isWithinHome(dir) || !dir.isDirectory())) {
            toast("~/projects is not a safe workspace directory.");
            return null;
        }
        if (!dir.exists() && !dir.mkdirs()) {
            toast("Could not create ~/projects.");
            return null;
        }
        return dir;
    }
    private boolean isWithinHome(File file) {
        try {
            String home = TermuxConstants.TERMUX_HOME_DIR.getCanonicalPath();
            String path = file.getCanonicalPath();
            return path.equals(home) || path.startsWith(home + File.separator);
        } catch (IOException e) { return false; }
    }
    private String read(File f) throws IOException {
        FileInputStream in = new FileInputStream(f);
        try { byte[] b = new byte[(int) f.length()]; int n = in.read(b); return new String(b, 0, Math.max(n, 0), StandardCharsets.UTF_8); }
        finally { in.close(); }
    }
    private void write(File f, String value) throws IOException {
        FileOutputStream out = new FileOutputStream(f, false);
        try { out.write(value.getBytes(StandardCharsets.UTF_8)); out.flush(); }
        finally { out.close(); }
    }
    private boolean deleteRecursively(File f) {
        if (isSymlink(f)) return f.delete();
        if (f.isDirectory()) { File[] c = f.listFiles(); if (c != null) for (File child : c) if (!deleteRecursively(child)) return false; }
        return f.delete();
    }
    private boolean isSymlink(File f) {
        try { return !f.getAbsolutePath().equals(f.getCanonicalPath()); }
        catch (IOException e) { return true; }
    }
    private String humanSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024L * 1024) return String.format(java.util.Locale.ROOT, "%.1f KB", bytes / 1024.0);
        return String.format(java.util.Locale.ROOT, "%.1f MB", bytes / (1024.0 * 1024));
    }
    private void card(String title, String detail, String action, Runnable onClick) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(16), dp(14), dp(16), dp(14));
        c.setBackground(round(CARD, BORDER, 20));
        TextView t = text(title, 15, TEXT, true); c.addView(t);
        TextView d = text(detail, 12, MUTED, false); d.setPadding(0, dp(7), 0, dp(12)); c.addView(d);
        TextView b = actionView(action, onClick); c.addView(b);
        body.addView(c);
    }
    private TextView actionView(String label, Runnable r) {
        TextView v = text(label, 13, ORANGE, true); v.setGravity(Gravity.CENTER_VERTICAL);
        v.setPadding(dp(12), dp(12), dp(12), dp(12)); v.setBackground(round(Color.rgb(36, 23, 16), BORDER, 14));
        v.setOnClickListener(x -> r.run()); return v;
    }
    private void action(String label, Runnable r) { body.addView(actionView(label, r)); }
    private void empty(String message) { TextView v = text(message, 13, MUTED, false); v.setPadding(dp(10), dp(18), dp(10), dp(18)); body.addView(v); }
    private void addGap() { View v = new View(this); body.addView(v, new LinearLayout.LayoutParams(1, dp(10))); }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView v = new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }
    private GradientDrawable round(int color, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); d.setStroke(dp(1), stroke); return d;
    }
    private int dp(float n) { return (int) (n * getResources().getDisplayMetrics().density + 0.5f); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
